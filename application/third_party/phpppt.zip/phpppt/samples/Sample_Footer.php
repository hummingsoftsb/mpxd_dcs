<?php
/**
 * Footer file
 */
?>
</div>
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="bootstrap/js/script.js"></script>
</body>
</html>