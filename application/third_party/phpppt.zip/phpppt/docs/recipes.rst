.. _recipes:

Recipes
=======

Title
-----------------------

Recipe Text

.. code-block:: php

    $content;
