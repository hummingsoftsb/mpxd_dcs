.. _credits:

Credits
=======

	Images from chart page come from the `LibreOffice Core <https://github.com/LibreOffice/core/tree/master/icon-themes/galaxy/chart2/res>`.